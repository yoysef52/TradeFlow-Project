#!/usr/bin/env bash
# Runs the whole core suite.  Needs: python3.11+, PyJWT, cryptography (with Argon2id), node (for the ICU cross-check),
# and - for the PostgreSQL tests - psql plus a superuser connection to a TEST server.
# WARNING: the PostgreSQL tests DROP and re-create databases named tf_core_*. Never point them at a server with real data.
set -u
cd "$(dirname "$0")"
python3 -m unittest discover -s tests -t . -v 2>&1
