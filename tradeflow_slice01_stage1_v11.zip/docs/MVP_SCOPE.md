# TradeFlow — MVP Scope

## 1. Purpose

This document is the single source of truth for MVP scope. Other canonical documents must not contradict it.

## 1.1 Baseline

The executable baseline of this scope is **Baseline Hardened**: `001_initial_mvp.sql` + `002_harden_mvp.sql` + `runner.py` (ADR-056, ADR-061). It is frozen: it changes only through a new migration and an ADR. Accepted decisions that shape this scope: ADR-056 … ADR-063 (see `ADR_ADDENDUM_056-063.md`).

## 1.2 First vertical slice (Slice 1)

```text
Login → Organization → Customer → Product → Purchase Request → Items → Price → Save → Retrieve → Audit
```

Pre-Invoice is **not** part of Slice 1 (see § 5 and ADR-060).

## 2. MVP Tables

1. organizations
2. roles
3. users
4. customers
5. product_categories
6. units
7. products
8. product_specification_templates
9. product_specification_fields
10. product_specification_values
11. purchase_requests
12. purchase_request_items
13. audit_logs
14. refresh_tokens
15. schema_migrations (infrastructure table; written only by the migration runner)
16. organization_request_counters (added by migration 002, ADR-057)

Schema change **implemented** (migration 003, tested 2026-10-10; the physical model in `DATA_MODEL.md` describes the state after 001+002): it adds `organizations.code` (`UNIQUE NOT NULL`) for login (ADR-059). It adds a column, not a table.

## 3. MVP Endpoints

Exactly the endpoints currently defined in `API_SPECIFICATION.md` § 25 (29 endpoints: 27 including `cancel` (ADR-062), plus the 2 read-only lookups of ADR-063). Request/response details: `SLICE_01_CONTRACT.md`. Login takes `organization_code`, `username` and `password` (ADR-059); `GET /organizations` returns the single organization of the current user; `organization_id` is never accepted from a request body or query (it comes from the token).

```text
POST /api/v1/auth/login
POST /api/v1/auth/refresh
POST /api/v1/auth/logout
GET  /api/v1/auth/me

GET  /api/v1/organizations
GET  /api/v1/organizations/{id}

GET  /api/v1/customers
POST /api/v1/customers
GET  /api/v1/customers/{id}
PATCH /api/v1/customers/{id}

GET  /api/v1/products
POST /api/v1/products
GET  /api/v1/products/{id}
PATCH /api/v1/products/{id}
GET  /api/v1/products/{id}/specifications
GET  /api/v1/product-categories                (read-only, ADR-063)
GET  /api/v1/units                             (read-only, ADR-063)

GET  /api/v1/purchase-requests
POST /api/v1/purchase-requests
GET  /api/v1/purchase-requests/{id}
PATCH /api/v1/purchase-requests/{id}
POST /api/v1/purchase-requests/{id}/submit
POST /api/v1/purchase-requests/{id}/cancel      (ADR-062)

POST /api/v1/purchase-requests/{id}/items
PATCH /api/v1/purchase-request-items/{id}
DELETE /api/v1/purchase-request-items/{id}

POST /api/v1/purchase-requests/{id}/pricing
GET  /api/v1/purchase-requests/{id}/pricing

GET  /api/v1/audit-logs
```

## 4. MVP Screens

- Login
- Dashboard (minimal)
- Customer List / Detail / Create-Edit
- Product List / Detail / Create-Edit / Specifications
- Purchase Request List / Detail / Form / Item Entry / Pricing
- Audit Log List
- Settings (Organization only)

## 5. Explicitly NOT MVP

**Accepted for a later step, not in Slice 1:**

- Pre-Invoice — decision accepted as **MVP+1** (ADR-060): an immutable snapshot issued from a `SUBMITTED` purchase request, after Slice 1 is complete and tested. Accepted does not mean implemented: no table, endpoint or screen exists in the baseline.

**Not MVP:**

- Payment
- Voucher
- Approval workflow
- Credit control
- Inventory / Reservation / ATP
- Shipment / Loading / Weighbridge / Release / Delivery / POD
- Dispute / Claim / Return
- Reconciliation
- Accounting connector implementation
- File / Document management subsystem
- Offline synchronization
- OCR / Geolocation / CRM
- Customer / Supplier portal
- Subscription / Feature flags
- Multi-currency implementation (MVP currency: whole Rial, `NUMERIC(20,0)`, ADR-058)
- Tax engine
- Cost / Margin analysis
- Advanced reporting
- Docker
- CI/CD
- ER / Sequence / State diagrams

## 6. Change Rule

Adding any item to MVP requires an ADR. Removing an item requires an ADR. Silent scope expansion is prohibited.

## 7. Reference Rule

Every canonical document must reference this file for scope decisions. Where any document conflicts with MVP_SCOPE.md, MVP_SCOPE.md wins.

## 8. Money Rule

Amounts are stored as whole Rial in `NUMERIC(20,0)`. Python uses `Decimal` with `ROUND_HALF_UP`. `NUMERIC(20,2)` and per-organization scale are not MVP (ADR-058).

## 9. Open Items

**Decisions D1–D17** of `SLICE_01_CONTRACT.md` § 20 (request number series, seeded master data + two read-only lookups, applicable-field rule, audit vocabulary, role matrix, submit rules, optimistic concurrency, cancel reason, content freeze, JWT/refresh/argon2id policy, self-sufficient dev seed 998, no draft-delete API, immutable item product, pricing batch, lookups, `organizations.code`, normalized usernames) are **Accepted** (2026-10-10), as is ADR-063. Review round 4 proposals C (failed-login counter without IP) and G (audit of failed logins) were **not adopted**: D10 and D4 stay in force (contract § 25).
