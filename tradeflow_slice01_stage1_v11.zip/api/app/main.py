"""FastAPI application factory. Routes are thin: parse -> service (in a worker thread) -> envelope."""
from __future__ import annotations

import logging
import uuid

import psycopg
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, Response
from starlette.concurrency import run_in_threadpool
from starlette.exceptions import HTTPException as StarletteHTTPException

from tradeflow_core.errors import AppError, ErrorCode
from tradeflow_core.inputs import data_envelope

from . import db as dbmod
from .auth_service import AuthService

log = logging.getLogger("tradeflow")
API = "/api/v1"


def _rid(request: Request) -> str:
    return getattr(request.state, "request_id", "-")


def error_response(request: Request, err: AppError) -> JSONResponse:
    headers = {}
    if err.code is ErrorCode.RATE_LIMITED and getattr(err, "retry_after", None):
        headers["Retry-After"] = str(err.retry_after)
    return JSONResponse(err.to_body(_rid(request)), status_code=err.http_status, headers=headers)


async def read_json(request: Request):
    try:
        return await request.json()
    except Exception:
        raise AppError(ErrorCode.MALFORMED_REQUEST)


def client_ip(request: Request) -> str:
    return request.client.host if request.client else ""


def create_app(settings, db=None, limiter=None, clock=None) -> FastAPI:
    app = FastAPI(title="TradeFlow API", docs_url=None, redoc_url=None, openapi_url=None)
    db = db or dbmod.Database(settings.database_dsn)
    kw = {"clock": clock} if clock else {}
    auth = AuthService(db, settings, limiter, **kw)
    app.state.db, app.state.auth, app.state.settings = db, auth, settings
    for w in settings.warnings:
        log.warning(w)

    @app.middleware("http")
    async def request_id_middleware(request: Request, call_next):
        request.state.request_id = str(uuid.uuid4())
        try:
            response = await call_next(request)
        except Exception:
            log.exception("unhandled error request_id=%s", request.state.request_id)
            response = error_response(request, AppError(ErrorCode.INTERNAL_ERROR))
        response.headers["X-Request-Id"] = request.state.request_id
        return response

    @app.exception_handler(AppError)
    async def _app_error(request, exc: AppError):
        return error_response(request, exc)

    @app.exception_handler(psycopg.Error)
    async def _pg_error(request, exc):
        err = dbmod.to_app_error(exc)
        if err.code is ErrorCode.INTERNAL_ERROR:
            log.error("database error request_id=%s sqlstate=%s", _rid(request), getattr(exc, "sqlstate", None))
        return error_response(request, err)

    @app.exception_handler(RequestValidationError)
    async def _validation(request, exc):
        return error_response(request, AppError(ErrorCode.VALIDATION_ERROR, details=[{"field": "$", "reason": "INVALID_REQUEST"}]))

    @app.exception_handler(StarletteHTTPException)
    async def _http(request, exc):
        return error_response(request, AppError(ErrorCode.NOT_FOUND if exc.status_code == 404 else ErrorCode.MALFORMED_REQUEST))

    async def principal(request: Request):
        return await run_in_threadpool(auth.authenticate, request.headers.get("authorization"))

    # ------------------------------------------------------------ auth endpoints
    @app.post(f"{API}/auth/login")
    async def login(request: Request):
        body = await read_json(request)
        data = await run_in_threadpool(auth.login, body, client_ip(request))
        return data_envelope(data, _rid(request))

    @app.post(f"{API}/auth/refresh")
    async def refresh(request: Request):
        body = await read_json(request)
        return data_envelope(await run_in_threadpool(auth.refresh, body), _rid(request))

    @app.post(f"{API}/auth/logout")
    async def logout(request: Request):
        p = await principal(request)
        body = await read_json(request)
        await run_in_threadpool(auth.logout, p, body, client_ip(request))
        return Response(status_code=204)

    @app.get(f"{API}/auth/me")
    async def me(request: Request):
        p = await principal(request)
        return data_envelope(p.user_json(), _rid(request))

    app.state.principal = principal           # reused by the next stages' routers
    return app
