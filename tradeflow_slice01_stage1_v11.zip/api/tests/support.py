"""Shared fixtures: a real database built from the migrations + dev seed, and an app wired to it."""
import os
from datetime import datetime, timezone

from app.main import create_app
from app.settings import AppSettings
from tradeflow_core import config as core_config
from tradeflow_core.ratelimit import LoginRateLimiter
from tests import pg

SQL_DIR = os.environ.get("TF_SQL_DIR")
DB = "tf_api_test"
PASSWORD = "TradeFlow-Dev-1!"
SECRET = "test-secret-" + "x" * 40


def ready():
    return bool(SQL_DIR) and pg.available()


def build_db():
    pg.make_db(DB, SQL_DIR)


def make_app(limiter=None, clock=None, grace=10):
    core = core_config.Settings(SECRET, 3600, 30, grace, 1, "test")
    return create_app(AppSettings(core, f"dbname={DB}", ()), limiter=limiter or LoginRateLimiter(), clock=clock)


def login_body(user="admin", password=PASSWORD, org="DEMO"):
    return {"organization_code": org, "username": user, "password": password}
