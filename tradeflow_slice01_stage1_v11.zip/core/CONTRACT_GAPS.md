# Points where the contract is silent and the core made a choice (owner should confirm)

1. quantity <= 0 → 422 VALIDATION_ERROR (format errors → INVALID_MONEY).
2. Login limiter is not reset by a successful login.
3. Logout with the caller's own already-revoked refresh token succeeds (idempotent).
4. Digit normalization is not applied to TEXT / SELECT specification values; only to numbers, dates, identifiers.
5. Malformed specification `field_id` → VALIDATION_ERROR; client-sent extra keys → VALIDATION_ERROR (reason NOT_ALLOWED for server-owned keys, UNKNOWN_FIELD otherwise).
6. Unbounded TEXT columns (address, notes) get an implementation limit of 5000 characters (inputs.TEXT_LIMIT).
7. UUID path/body values: upper-case accepted, canonical lower-case returned; hyphen-less rejected.
8. Quantity/weight accept ASCII or Persian/Arabic digits but NOT the Arabic decimal separator (contract allows it only for DECIMAL specs).
9. Pagination: page >= 1 default 1; page_size 1..200 default 50 (check against the contract section on lists).
10. normalize_identifier depends on the database locale: `[[:space:]]` is ASCII-only under the C locale (verified; mirror matches 1500 random strings), but may also match Unicode spaces (e.g. U+2003) in a UTF-8 locale. Production should state its locale; if it is not C, the Python mirror (used for search only) may differ for such characters.
11. Request numbers: supported series years 1400–1499 only.
12. WORKERS must be 1 (in-process limiter).
